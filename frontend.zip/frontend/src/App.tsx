import { useEffect, useMemo, useState } from 'react';
import { MapContainer, TileLayer, CircleMarker, Popup, Polyline, useMap } from 'react-leaflet';
import type { LatLngBoundsExpression } from 'leaflet';

type Stop = { stop_id: string; name: string; lat: number; lon: number; code?: string };
type Route = { route_id: string; short_name: string; long_name: string; route_type: number | string; route_color?: string; route_text_color?: string; directions?: string[]; trip_count?: number };
type Stats = { stops: number; routes: number; trips: number; source: string };
type RouteTrip = { trip_id: string; headsign: string; coordinates: [number, number][]; stops: Stop[] };
type RouteMap = { route: Route | null; trips: RouteTrip[] };
type Departure = { trip_id: string; stop_id: string; route_id: string; route_short_name: string; route_type: number | string; headsign: string; stop_name: string; departure_time: string; departure_display: string; route_color?: string };
type DepartureResponse = { stop: Stop | null; date: string; source: string; calendar_available: boolean; total: number; departures: Departure[]; message: string };
const todayIso = () => { const now = new Date(); const local = new Date(now.getTime() - now.getTimezoneOffset() * 60000); return local.toISOString().slice(0, 10); };
const API = '/api';
const typeLabel = (type: number | string) => ({ 0: 'Tramwaj', 1: 'Metro', 2: 'Kolej', 3: 'Autobus', 4: 'Prom' } as Record<number, string>)[Number(type)] || 'Transport';
const typeIcon = (type: number | string) => ({ 0: '🚊', 1: '🚇', 2: '🚆', 3: '🚌', 4: '⛴️' } as Record<number, string>)[Number(type)] || '🚍';
const routeColor = (route?: Route) => route?.route_color && /^[0-9a-f]{6}$/i.test(route.route_color) ? `#${route.route_color}` : '#2563eb';

function MapFit({ coords, selectedStop }: { coords: [number, number][]; selectedStop: Stop | null }) {
  const map = useMap();
  useEffect(() => {
    if (coords.length > 1) map.fitBounds(coords as LatLngBoundsExpression, { padding: [35, 35], maxZoom: 14 });
    else if (selectedStop) map.setView([selectedStop.lat, selectedStop.lon], 15);
  }, [map, coords, selectedStop]);
  return null;
}

export default function App() {
  const [stops, setStops] = useState<Stop[]>([]);
  const [routes, setRoutes] = useState<Route[]>([]);
  const [stats, setStats] = useState<Stats | null>(null);
  const [stopSearch, setStopSearch] = useState('');
  const [routeSearch, setRouteSearch] = useState('');
  const [selectedStop, setSelectedStop] = useState<Stop | null>(null);
  const [stopRoutes, setStopRoutes] = useState<Route[]>([]);
  const [selectedRoute, setSelectedRoute] = useState<Route | null>(null);
  const [routeMap, setRouteMap] = useState<RouteMap | null>(null);
  const [tripIndex, setTripIndex] = useState(0);
  const [error, setError] = useState('');
  const [stopRoutesError, setStopRoutesError] = useState('');
  const [scheduleDate, setScheduleDate] = useState(todayIso());
  const [scheduleRouteId, setScheduleRouteId] = useState('');
  const [departures, setDepartures] = useState<Departure[]>([]);
  const [scheduleTotal, setScheduleTotal] = useState(0);
  const [scheduleMessage, setScheduleMessage] = useState('');
  const [scheduleLoading, setScheduleLoading] = useState(false);

  useEffect(() => {
    Promise.all([fetch(`${API}/stats`), fetch(`${API}/stops?limit=10000`), fetch(`${API}/routes`)]).then(async ([sr, st, rr]) => {
      if (!sr.ok || !st.ok || !rr.ok) throw new Error(`API HTTP: stats ${sr.status}, przystanki ${st.status}, linie ${rr.status}`);
      const [statsData, stopData, routeData] = await Promise.all([sr.json(), st.json(), rr.json()]);
      if (!Array.isArray(stopData) || !Array.isArray(routeData)) throw new Error('API zwróciło nieprawidłowy format danych');
      setStats(statsData); setStops(stopData); setRoutes(routeData);
    }).catch(e => setError(e instanceof Error ? e.message : String(e)));
  }, []);

  const filteredStops = useMemo(() => {
    const term = stopSearch.trim().toLocaleLowerCase('pl-PL');
    return stops.filter(s => !term || s.name.toLocaleLowerCase('pl-PL').includes(term) || s.stop_id.toLocaleLowerCase().includes(term)).slice(0, 100);
  }, [stops, stopSearch]);
  const filteredRoutes = useMemo(() => {
    const term = routeSearch.trim().toLocaleLowerCase('pl-PL');
    return routes.filter(r => `${r.short_name} ${r.long_name} ${typeLabel(r.route_type)}`.toLocaleLowerCase('pl-PL').includes(term))
      .sort((a, b) => a.short_name.localeCompare(b.short_name, 'pl', { numeric: true }));
  }, [routes, routeSearch]);
  const activeTrip = routeMap?.trips[Math.min(tripIndex, Math.max(0, routeMap.trips.length - 1))] ?? null;
  const activeCoordinates = activeTrip?.coordinates ?? [];

  async function chooseStop(stop: Stop) {
    setSelectedStop(stop); setSelectedRoute(null); setRouteMap(null); setTripIndex(0); setStopRoutesError(''); setDepartures([]); setScheduleMessage(''); setScheduleRouteId('');
    try {
      const response = await fetch(`${API}/stops/${encodeURIComponent(stop.stop_id)}/routes`);
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      const data = await response.json();
      setStopRoutes(Array.isArray(data.routes) ? data.routes : []);
      if (!data.routes?.length) setStopRoutesError(stats?.source?.toLowerCase().includes('sample') ? 'Wczytano dane przykładowe, które nie zawierają tego przystanku. Pobranie pełnego GTFS Warszawy nie powiodło się.' : `Nie znaleziono linii dla tego przystanku. Powiązane identyfikatory GTFS: ${(data.matched_stop_ids ?? []).join(', ') || 'brak'}. Sprawdź diagnostykę API.`);
    } catch (e) { setStopRoutesError(`Nie udało się pobrać linii dla przystanku: ${e instanceof Error ? e.message : String(e)}`); setStopRoutes([]); }
  }
  async function loadDepartures() {
    if (!selectedStop) return;
    setScheduleLoading(true); setScheduleMessage(''); setDepartures([]);
    try {
      const params = new URLSearchParams({ date: scheduleDate, limit: '300' });
      if (scheduleRouteId) params.set('route_id', scheduleRouteId);
      const response = await fetch(`${API}/stops/${encodeURIComponent(selectedStop.stop_id)}/departures?${params}`);
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      const data: DepartureResponse = await response.json();
      setDepartures(Array.isArray(data.departures) ? data.departures : []);
      setScheduleTotal(data.total ?? 0);
      setScheduleMessage(data.message || (data.calendar_available ? '' : 'Feed nie zawiera kalendarza kursowania; wyświetlono dostępne kursy bez filtrowania po dniu.'));
    } catch (e) {
      setScheduleMessage(`Nie udało się pobrać rozkładu: ${e instanceof Error ? e.message : String(e)}`);
    } finally { setScheduleLoading(false); }
  }
  async function chooseRoute(route: Route) {
    setSelectedRoute(route); setRouteMap(null); setTripIndex(0);
    try {
      const response = await fetch(`${API}/routes/${encodeURIComponent(route.route_id)}/map`);
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      const data = await response.json(); setRouteMap(data);
      if (!data.trips?.length) setStopRoutesError('Brak danych przebiegu tej linii (geometrii lub kolejności przystanków) w feedzie.');
      else setStopRoutesError('');
    } catch (e) { setStopRoutesError(`Nie udało się wczytać przebiegu linii: ${e instanceof Error ? e.message : String(e)}`); }
  }
  const mapCenter: [number, number] = selectedStop ? [selectedStop.lat, selectedStop.lon] : [52.2297, 21.0122];

  return <main>
    <header><div className="brand">Czy dojadę?</div><div className="subtitle">Dostępność transportu publicznego w Warszawie</div></header>
    <section className="cards">
      <article><span>Przystanki</span><strong>{stats?.stops?.toLocaleString('pl-PL') ?? '…'}</strong></article>
      <article><span>Linie</span><strong>{stats?.routes?.toLocaleString('pl-PL') ?? routes.length.toLocaleString('pl-PL')}</strong></article>
      <article><span>Kursy w feedzie</span><strong>{stats?.trips?.toLocaleString('pl-PL') ?? '…'}</strong></article>
      <article><span>Źródło danych</span><strong className="small">{stats?.source ?? '…'}</strong></article>
    </section>
    {error && <div className="error">Błąd pobierania API: {error}</div>}
    {stats?.source?.toLowerCase().includes("sample") && <div className="error"><strong>Uwaga: wczytano dane przykładowe, nie pełny rozkład Warszawy.</strong> Pobranie GTFS nie powiodło się. Na danych przykładowych linie będą dostępne tylko dla kilku przykładowych przystanków. Sprawdź API: <a href="/api/health" target="_blank" rel="noreferrer">status</a> i <a href="/api/diagnostics/linkage" target="_blank" rel="noreferrer">diagnostykę powiązań</a>.</div>}

    <section className="stop-panel">
      <h1>Jakie linie jeżdżą na przystanku?</h1>
      <p>Wyszukaj przystanek, wybierz go z podpowiedzi i zobacz obsługujące go linie.</p>
      <input value={stopSearch} onChange={e => { setStopSearch(e.target.value); setSelectedStop(null); setStopRoutes([]); setSelectedRoute(null); setRouteMap(null); }} placeholder="Wpisz nazwę przystanku, np. Centrum…" aria-label="Szukaj przystanku" />
      {stopSearch.trim() && !selectedStop && <div className="stop-suggestions">{filteredStops.slice(0, 12).map(stop => <button key={stop.stop_id} className="suggestion" onClick={() => chooseStop(stop)}><span>{stop.name}</span><small>{stop.stop_id}</small></button>)}{!filteredStops.length && <p>Brak pasujących przystanków.</p>}</div>}
      {selectedStop && <div className="selected-stop"><div><strong>{selectedStop.name}</strong><small> ID: {selectedStop.stop_id}</small></div><button className="secondary" onClick={() => {setSelectedStop(null);setStopSearch('');setStopRoutes([]);setSelectedRoute(null);setRouteMap(null);}}>Wyczyść wybór</button></div>}
      {selectedStop && <div className="stop-routes"><h2>Linie na przystanku: {stopRoutes.length}</h2>{stopRoutesError && <div className="error">{stopRoutesError}</div>}
        {stopRoutes.length ? <div className="line-chips">{stopRoutes.map(r => <button key={r.route_id} className="line-chip" style={{borderColor: routeColor(r)}} onClick={() => chooseRoute(r)}><span className="route-badge" style={{backgroundColor:routeColor(r), color:r.route_text_color && /^[0-9a-f]{6}$/i.test(r.route_text_color) ? `#${r.route_text_color}` : '#fff'}}>{r.short_name || '—'}</span><span>{typeIcon(r.route_type)} {typeLabel(r.route_type)}</span></button>)}</div> : !stopRoutesError && <p>Ładowanie linii…</p>}
      </div>}
      {selectedStop && <div className="schedule-panel">
        <h2>Rozkład jazdy — godziny odjazdów</h2>
        <div className="schedule-controls">
          <label>Data: <input type="date" value={scheduleDate} onChange={e => setScheduleDate(e.target.value)} /></label>
          <label>Linia: <select value={scheduleRouteId} onChange={e => setScheduleRouteId(e.target.value)}><option value="">Wszystkie linie</option>{stopRoutes.map(r => <option key={r.route_id} value={r.route_id}>{r.short_name} — {typeLabel(r.route_type)}</option>)}</select></label>
          <button className="schedule-button" onClick={loadDepartures} disabled={scheduleLoading}>{scheduleLoading ? 'Pobieranie…' : 'Pokaż odjazdy'}</button>
        </div>
        {scheduleMessage && <p className="schedule-note">{scheduleMessage}</p>}
        {departures.length > 0 && <><p className="schedule-note">Znaleziono {scheduleTotal} odjazdów. Rozkład statyczny GTFS (nie dane realtime).</p><div className="departures-table-wrap"><table className="departures-table"><thead><tr><th>Godzina</th><th>Linia</th><th>Kierunek</th><th>Typ</th></tr></thead><tbody>{departures.map((d, i) => <tr key={`${d.trip_id}-${d.stop_id}-${i}`}><td className="departure-time">{d.departure_display}</td><td><span className="route-badge schedule-route" style={{backgroundColor: d.route_color && /^[0-9a-f]{6}$/i.test(d.route_color) ? `#${d.route_color}` : '#2563eb', color:'#fff'}}>{d.route_short_name || '—'}</span></td><td>{d.headsign || 'Kierunek nieznany'}</td><td>{typeIcon(d.route_type)} {typeLabel(d.route_type)}</td></tr>)}</tbody></table></div></>}
      </div>}
    </section>

    <section className="routes-panel">
      <details className="routes-accordion"><summary><div><h1>Linie komunikacji miejskiej</h1><p>Rozwiń, aby wyszukać linię i zobaczyć jej przebieg na mapie.</p></div><strong className="routes-count">{routes.length} linii　⌄</strong></summary>
        <input value={routeSearch} onChange={e => setRouteSearch(e.target.value)} placeholder="Filtruj linie (np. 1, 175, M1)…" aria-label="Filtruj linie" />
        {routes.length === 0 && !error && <p className="muted">Wczytywanie linii…</p>}
        <div className="routes-grid">{filteredRoutes.map(route => <button className={`route-card ${selectedRoute?.route_id === route.route_id ? 'route-card-active' : ''}`} key={route.route_id} onClick={() => chooseRoute(route)}>
          <span className="route-badge" style={{backgroundColor:routeColor(route), color:route.route_text_color && /^[0-9a-f]{6}$/i.test(route.route_text_color) ? `#${route.route_text_color}` : '#fff'}}>{route.short_name || '?'}</span>
          <div className="route-info"><strong>{typeIcon(route.route_type)} {typeLabel(route.route_type)}</strong><small>{route.long_name || 'Nazwa trasy niedostępna'}</small></div>
        </button>)}</div>
      </details>
    </section>

    <section className="map-panel">
      <div className="map-title"><h1>Mapa Warszawy — przystanki i trasy</h1><p>{selectedRoute ? `Wybrana linia ${selectedRoute.short_name}${activeTrip?.headsign ? ` — kierunek: ${activeTrip.headsign}` : ''}` : selectedStop ? `Zaznaczony przystanek: ${selectedStop.name}` : 'Wybierz przystanek lub linię, aby wyświetlić ją na mapie.'}</p>
        {selectedRoute && routeMap?.trips?.length > 1 && <label className="trip-picker">Kierunek / wariant: <select value={tripIndex} onChange={e => setTripIndex(Number(e.target.value))}>{routeMap.trips.map((t, i) => <option key={t.trip_id} value={i}>{t.headsign || `Wariant ${i + 1}`} · {t.stops.length} przystanków</option>)}</select></label>}
      </div>
      <MapContainer center={mapCenter} zoom={selectedStop ? 15 : 12} scrollWheelZoom className="map"><TileLayer attribution='&copy; OpenStreetMap contributors' url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />
        <MapFit coords={activeCoordinates} selectedStop={selectedStop}/>
        {filteredStops.slice(0, 100).map(s => <CircleMarker key={s.stop_id} center={[s.lat, s.lon]} radius={selectedStop?.stop_id === s.stop_id ? 8 : 4} pathOptions={{color:selectedStop?.stop_id === s.stop_id ? '#f97316' : '#2563eb', fillOpacity:.8}} eventHandlers={{click:()=>chooseStop(s)}}><Popup><b>{s.name}</b><br/>ID: {s.stop_id}<br/><button onClick={()=>chooseStop(s)}>Sprawdź linie</button></Popup></CircleMarker>)}
        {activeCoordinates.length > 1 && <Polyline positions={activeCoordinates} pathOptions={{color:routeColor(selectedRoute ?? undefined),weight:6,opacity:.85}}/>}
        {activeTrip?.stops.map((s, i) => <CircleMarker key={`${activeTrip.trip_id}-${s.stop_id}-${i}`} center={[s.lat,s.lon]} radius={4} pathOptions={{color:routeColor(selectedRoute ?? undefined),fillColor:'#fff',fillOpacity:1}}><Popup><b>{s.name}</b><br/>Przystanek {i+1} na trasie</Popup></CircleMarker>)}
        {selectedStop && <CircleMarker center={[selectedStop.lat,selectedStop.lon]} radius={9} pathOptions={{color:'#f97316',fillColor:'#fb923c',fillOpacity:1}}><Popup><b>{selectedStop.name}</b><br/>Wybrany przystanek</Popup></CircleMarker>}
      </MapContainer>
      {activeTrip && <div className="route-itinerary"><strong>Przystanki wariantu ({activeTrip.stops.length}):</strong><div className="itinerary-list">{activeTrip.stops.map((s,i)=><span key={`${s.stop_id}-${i}`} className="itinerary-stop">{i+1}. {s.name}</span>)}</div></div>}
    </section>
    <footer>Dane rozkładowe GTFS Warszawa · Mapa: OpenStreetMap. Przebieg linii pochodzi z shapes.txt, a jeśli brakuje geometrii — z kolejności przystanków zapisanych w GTFS.</footer>
  </main>;
}
